<?php 
    defined('C5_EXECUTE') or die(_("Access Denied.")); 
	

	
	if($listing==1){
		
 $this->controller->listings();

		}

	else{ ?>
    
		<h2>IDX Listing are Disabled</h2>
	
<?php	} ?>	


  
 
