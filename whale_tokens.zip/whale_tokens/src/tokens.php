<?php 
/**
 * @author 		shahroq <shahroq \at\ yahoo.com>
 * @copyright  	Copyright (c) 2014 shahroq.
 * http://concrete5.killerwhalesoft.com/addons/
 */

namespace Concrete\Package\WhaleTokens\Src;

use Loader;
use Page;
use Package;

class Tokens
{

    public static $conf = array();
    public static $token_keys = array();
    public static $token_values = array();

	public function replaceTokens($html=false){

        Tokens::getConfigs();

        $c = Page::getCurrentPage();
		if(!$c || $c->isAdminArea()|| $c->isEditMode()){
			return $html;
		}

		Tokens::getTokens();

        if(Tokens::$conf['WHALE_TOKENS_ENABLE']!=1){
			$html['contents'] = str_replace(Tokens::$token_keys, '', $html['contents']);
			return $html;
        }


		if(Tokens::$conf['WHALE_TOKENS_CASE_SENSITIVE']==1){
			$html['contents'] = str_replace(Tokens::$token_keys, Tokens::$token_values, $html['contents']);
		}else{
			$html['contents'] = str_ireplace(Tokens::$token_keys, Tokens::$token_values, $html['contents']);
		}

		return $html;
	}

    private function getTokens(){
		//get record:
	    $db = Loader::db();
		$rslt = $db->Execute("SELECT tokenKey, tokenValue FROM `WhaleTokens` WHERE active=1;");

		foreach($rslt as $row){
			Tokens::$token_keys[] = Tokens::$conf['WHALE_TOKENS_WRAPPERS_AR'][0].$row['tokenKey'].Tokens::$conf['WHALE_TOKENS_WRAPPERS_AR'][1];
			Tokens::$token_values[] = $row['tokenValue'];
		}

	}

    private function getConfigs(){
        $pkg  = Package::getByHandle('whale_tokens');
        Tokens::$conf = array('WHALE_TOKENS_ENABLE' => $pkg->getConfig()->get('tokens.WHALE_TOKENS_ENABLE'),
        					'WHALE_TOKENS_WRAPPERS' => $pkg->getConfig()->get('tokens.WHALE_TOKENS_WRAPPERS'),
        					'WHALE_TOKENS_CASE_SENSITIVE' => $pkg->getConfig()->get('tokens.WHALE_TOKENS_CASE_SENSITIVE')
                           );
		//divide token wrappers, if exist, and prepare them an an array for further use:
        $wrappers_ar = array("","");
        if(strlen(Tokens::$conf['WHALE_TOKENS_WRAPPERS'])==2) $wrappers_ar = str_split ( Tokens::$conf['WHALE_TOKENS_WRAPPERS'] , 1 );
		Tokens::$conf['WHALE_TOKENS_WRAPPERS_AR'] = $wrappers_ar;

	}
}