<?php 
/**
 * @author 		shahroq <shahroq \at\ yahoo.com>
 * @copyright  	Copyright (c) 2014 shahroq.
 * http://concrete5.killerwhalesoft.com/addons/
 */

namespace Concrete\Package\WhaleTokens;
use Core;
use Package;
use SinglePage;
use Loader;
use \Concrete\Core\Http\Request;
use Events;
use \Concrete\Package\WhaleTokens\Src\tokens;

defined('C5_EXECUTE') or die(_("Access Denied."));

class Controller extends Package {

	protected $pkgHandle = 'whale_tokens';
    protected $appVersionRequired = '5.7.3';
    protected $pkgVersion = '1.0.0';

	public function getPackageDescription() {
        return t("Whale Tokens, enables you to create sitewide variables and use them on all blocks.");
    }

    public function getPackageName() {
        return t("Tokens");
    }

	public function install() {
		$pkg = parent::install();

		$this->install_single_page($pkg);
        $this->save_configs($pkg);
	}

	public function on_start() {
		$wt = new Tokens();
		Events::addListener(
							'on_page_output',
        					//'replaceTokens'
        					array($wt,'replaceTokens')
							);

    }

 	private function install_single_page($pkg){

		Loader::model('single_page');

		//Begin: GENERAL stuffs
		//create a box at dashboard  for placing all links at dashboard:
		$p = SinglePage::add('/dashboard/tokens/',$pkg);
		if (is_object($p)) {
			$p->update(array('cName' => $this->getPackageName(), 'cDescription' => $this->getPackageDescription()));
		}
		//End: GENERAL stuffs

		//Tokens
		$p = SinglePage::add('/dashboard/tokens/tokens',$pkg);
		if (is_object($p)) {
			$p->update(array('cName'=>'Tokens'));
		}

        //Settings
        $p = SinglePage::add('/dashboard/tokens/settings',$pkg);
        if (is_object($p) && $p->isError() !== false) {
            $p->update(array('cName'=>'Settings'));
        }

	}

    private function save_configs($pkg){
        //import page configs:
        $pkg->getConfig()->save('tokens.WHALE_TOKENS_ENABLE', 1);
        $pkg->getConfig()->save('tokens.WHALE_TOKENS_WRAPPERS', '{}');
        $pkg->getConfig()->save('tokens.WHALE_TOKENS_CASE_SENSITIVE', 0);
    }

	public function uninstall() {
		parent::uninstall();

		//drop tables
		$db = Loader::db();
		$db->Execute('DROP TABLE IF EXISTS `WhaleTokens`');

	}

}