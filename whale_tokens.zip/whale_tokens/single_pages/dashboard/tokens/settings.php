<?php 
defined('C5_EXECUTE') or die(_("Access Denied."));
$fh = Loader::helper('form');

$task = 'update';
$buttonText = t('Update Settings');
?>


    <!--begin:form:-->
    <form method="post" action="<?php   echo $this->action($task)?>" id="form" class="">
	<div class="ccm-pane-body" id="whale-form">

    <!--BEGIN: Token Settings-->
    <div class="well" id="whale-form-items">
        <h2>
            <?php   echo t('Tokens Settings') ?>
            <a href="#form_setting" class="show-hide pull-right" title="<?php   echo t('Click to Show/Hide')?>"><i class="fa fa-chevron-up"></i></a>
        </h2>
        <div id="form_setting">

            <hr>
            <div class="row">
                <label class="col-xs-5 control-label">
                    <?php  echo t('Enable') ?>
                    <p class="text-muted">
                    <?php  echo t('Enable token system on your site.')?>
                    <br>
                    <?php  echo t('Disable token system also remove all used tokens.')?>
                    </p>
                </label>
                <div class="col-xs-2">
                    <?php 
                    $fld = 'WHALE_TOKENS_ENABLE';
                    $ini_value = (isset($POST[$fld])) ? $POST[$fld]:$conf[$fld];
                    echo $fh->checkbox($fld, 1, $ini_value, array());
                    ?>
                </div>
                <div class="col-xs-5"></div>
            </div>

            <hr>
            <div class="row">
                <label class="col-xs-5 control-label">
                    <?php  echo t('Wrappers') ?>
                    <p class="text-muted"><?php  echo t('Specify wrapper of tokens. Optional but recommended.')?></p>
                </label>
                <div class="col-xs-2">
                    <?php 
                    $fld = 'WHALE_TOKENS_WRAPPERS';
                    $ini_value = (isset($POST[$fld])) ? $POST[$fld]:$conf[$fld];
                    echo $fh->text($fld, $ini_value, array('maxlength' => '255', 'placeholder' => '', 'style' => ''));
                    ?>
                </div>
                <div class="col-xs-5"></div>
            </div>

            <hr>
            <div class="row">
                <label class="col-xs-5 control-label">
                    <?php  echo t('Case Sensitive') ?>*
                    <p class="text-muted"><?php  echo t('Enable Case Sensitivity.')?></p>
                </label>
                <div class="col-xs-2">
                    <?php 
                    $fld = 'WHALE_TOKENS_CASE_SENSITIVE';
                    $ini_value = (isset($POST[$fld])) ? $POST[$fld]:$conf[$fld];
                    echo $fh->checkbox($fld, 1, $ini_value, array());
                    ?>
                </div>
                <div class="col-xs-5"></div>
            </div>

        </div>
    </div>
    <!--END: Token Settings-->

    <!-- Begin: Buttons -->
    <div class="ccm-dashboard-form-actions-wrapper">
    <div class="ccm-dashboard-form-actions">
        <a href="<?php  echo URL::page($c)?>" class="btn btn-default pull-left"><?php  echo t('Back')?></a>
        <button type="submit" class="btn btn-primary pull-right"><?php  echo $buttonText ?></button>
    </div>
    </div>
    <!-- END: Buttons -->

    </div>
	</form>

