<?php 
defined('C5_EXECUTE') or die("Access Denied.");

// Helpers
$fh = Loader::helper('form');
$th = Loader::helper('text');
?>

<?php   if ($this->controller->getTask() == 'update' || $this->controller->getTask() == 'edit' || $this->controller->getTask() == 'add') { ?>
<!--BEGIN: Add/Edit Form-->
<?php 
	$task = 'add';
	$buttonText = t('Add Token');
	if ($this->controller->getTask() != 'add') {
		$task = 'update';
		$buttonText = t('Update Token');
	}
?>


    <!--begin:form:-->
	<form method="post" action="<?php   echo $this->action($task)?>" id="form" class="">
	<div class="ccm-pane-body" id="whale-form">

	<?php 
	if ($this->controller->getTask() != 'add') {
		echo $fh->hidden('tokenID', $record['tokenID']);
	}
	?>

	<!--BEGIN: Items Box-->
	<div class="well" id="whale-form-items">
		<h2>
		    <?php   echo t('Token') ?>
            <a href="#form_items" class="show-hide pull-right" title="Click to show/hide"><i class="fa fa-chevron-up"></i></a>
		</h2>
		<div id="form_items">

	        <hr>
	        <div class="row">
	            <label class="col-xs-5 control-label">
	                <?php  echo t('Key') ?>*
	            </label>
	            <div class="col-xs-7">
	                <?php 
	                $fld = 'tokenKey';
	                $ini_value = $record[$fld];
	                echo $fh->text($fld, $ini_value, array('maxlength' => '255', 'placeholder' => '', 'style' => ''));
	                ?>
	            </div>
	        </div>

	        <hr>
	        <div class="row">
	            <label class="col-xs-5 control-label">
	                <?php  echo t('Value') ?>
	            </label>
	            <div class="col-xs-7">
	                <?php 
	                $fld = 'tokenValue';
	                $ini_value = $record[$fld];
	                echo $fh->textarea($fld, $ini_value, array('maxlength' => '255', 'placeholder' => '', 'style' => ''));
	                ?>
	            </div>
	        </div>

	        <hr>
	        <div class="row">
	            <label class="col-xs-5 control-label">
	                <?php  echo t('Active') ?>
	            </label>
	            <div class="col-xs-7">
	                <?php 
	                $fld = 'active';
	                $ini_value = $record[$fld];
	                echo $fh->checkbox($fld, 1, $ini_value, array());
	                ?>
	            </div>
	        </div>

	    </div>
	</div>
	<!--END: Items Box-->

	<!-- Begin: Buttons -->
    <div class="ccm-dashboard-form-actions-wrapper">
    <div class="ccm-dashboard-form-actions">
        <a href="<?php  echo URL::page($c)?>" class="btn btn-default pull-left"><?php  echo t('Back')?></a>
        <button type="submit" class="btn btn-primary pull-right"><?php  echo $buttonText ?></button>
    </div>
    </div>
	<!-- END: Buttons -->

	</div>
    </form>
    <!--end:form-->


<!--END: Add/Edit Form-->
<?php   }else{ ?>
<!--BEGIN: GRID-->

<div class="ccm-dashboard-content-full">

    <div class="ccm-dashboard-header-buttons">
        <a class="btn btn-primary" href="<?php   echo $this->action('add')?>">
            <i title="Add" class="fa fa-plus-circle"></i>
            <?php   echo t('Add New Token');?>
        </a>
    </div>

    <div data-search-element="wrapper">
        <form role="form" data-search-form="whale-tokens" action="<?php  echo $controller->action('view')?>" class="form-inline ccm-search-fields">
            <div class="ccm-search-fields-row">
                 <div class="form-group" style="width:97%;">
                        <?php  echo $fh->label('fKeywords', t('Search'))?>
                        <div class="ccm-search-field-content">
                            <div class="ccm-search-main-lookup-field">
                                <i class="fa fa-search"></i>
                                <?php  echo $fh->search('fKeywords', array('placeholder' => t('Keywords')))?>
                                <button type="submit" class="ccm-search-field-hidden-submit" tabindex="-1"><?php  echo t('Search')?></button>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-info pull-right"><?php  echo t('Search')?></button>
                    </div>
                </div>
            <div class="ccm-search-fields-submit">

            </div>
        </form>
    </div>

    <form method="post" action="<?php   echo $this->action('mass_update')?>" id="mass-update-form">
    <div data-search-element="results">
        <div class="table-responsive">

        <?php  if(count($list) > 0) { ?>
            <table class="ccm-search-results-table">
                <thead>
                <tr>
                    <th><span><input id="ccm-list-cb-all" type="checkbox" data-search-checkbox="select-all"></span></th>
                    <th><span><?php   echo t('ID')?></span></th>
                    <th style="width:30%"><span><?php   echo t('Key')?></span></th>
                    <th style="width:40%"><span><?php   echo t('Value')?></span></th>
                    <th><span><?php   echo t('Active')?></span></th>
                    <th><span><?php   echo t('Operations')?></span></th>
                </tr>
                </thead>
                <tbody>
                <?php   foreach((array)$list as $item){ ?>
                <tr>
		        	<td class="ccm-list-cb" style="vertical-align: middle !important"><input name="cb_items[]" type="checkbox" value="<?php   echo $item['tokenID'] ?>" /></td>
					<td><?php   echo $item['tokenID'] ?></td>
					<td class="tokenKey" value="<?php   echo $conf['WHALE_TOKENS_WRAPPERS_AR'][0].htmlspecialchars($item['tokenKey']).$conf['WHALE_TOKENS_WRAPPERS_AR'][1] ?>">
					<?php 
					echo '<span class="muted">'.$conf['WHALE_TOKENS_WRAPPERS_AR'][0].'</span>'.htmlspecialchars($item['tokenKey']).'<span class="muted">'.$conf['WHALE_TOKENS_WRAPPERS_AR'][1].'</span>';
					?>
		            </td>
		            <td><?php   echo (strlen($item['tokenValue'])>0) ? $th->shorten(htmlspecialchars($item['tokenValue']), 255):"&nbsp;" ?></td>
		            <td align="center"><?php   echo ($item['active'])?'<i class="fa fa-check"></i>':'<i class="fa fa-minus"></i>' ?></td>
                    <td>
                        <a href="<?php   echo $this->action('edit/'.$item['tokenID'])?>" class="btn btn-primary">
                            <i class="fa fa-edit"></i>
                            <?php   echo t("Edit")?>
                        </a>
                    </td>
                </tr>
                <?php   } ?>
                </tbody>
            </table>
        <?php  }else{ ?>
            <div class="ccm-search-fields-row" style="font-weight: bold;">
            <?php   echo t('No record found.') ?>
            </div>
        <?php  } ?>

        </div>
    </div>

    <?php  echo (isset($l))?$l->displayPagingV2():''?>

    <?php  if(count($list) > 0) {?>
    <!-- Begin: Buttons -->
        <div class="ccm-dashboard-form-actions-wrapper">
        <div class="ccm-dashboard-form-actions">
            <?php  //echo $fh->submit('ccm-delete', t('Delete'), array('style' => '', 'class'=>'btn btn-danger pull-right', 'onclick'=>'return confirm_delete()')); ?>
            <?php 
            echo $fh->submit('ccm-mass-update', t('Delete'), array('style' => 'margin-right:5px;', 'class'=>'btn btn-danger pull-right', 'onclick'=>'return confirm_delete()'));
            ?>
        </div>
        </div>
    <!-- : Buttons -->
    <?php  } ?>

    </form>

</div>

<!--END: GRID-->
<?php   } ?>

<script type="text/javascript">
$(document).ready(function () {
});

//delete confirmation
function confirm_delete(){
    msg = "<?php   echo t('Are you sure?') ?>";
    return confirm(msg);
}
</script>