$(document).ready(function() {
    //select all checkbox
    $('#ccm-list-cb-all').click(function(){
        $("input[type='checkbox']").prop('checked', this.checked);
    });

    //expand/collapse
    //$("a.show-hide").click(function (e) {
    $('body').on('click', 'a.show-hide', function(e) {
        e.preventDefault();
        var ref = $(this).attr("href");
        //var target = $(ref);
		var target = $(this).closest("div.well").find(ref);
        //console.log("==>");
        //console.log(target);
        if (target.is(":visible")) {
            $(this).find("i").attr("class", "fa fa-chevron-down");
            target.stop(true, true).slideUp();
        } else {
            $(this).find("i").attr("class", "fa fa-chevron-up");
            target.stop(true, true).slideDown();
        }
        return false
    });

/*
    $("td.tokenKey").on("click", function() {
        value = $(this).attr("value");
        content = $(this).html();
        $(this).html("<input type='text' value='" + value + "' readonly>");
        $(this).children(":text").focus();
        return false;
      });
      $("td.tokenKey :text").on("click", function() {
        console.log("blue");
        $(this).parent().html(content);
      });
*/
});