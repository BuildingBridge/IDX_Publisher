<?php 
namespace Concrete\Package\WhaleTokens\Controller\SinglePage\Dashboard;
use \Concrete\Core\Page\Controller\DashboardPageController;

class tokens extends DashboardPageController
{

    public function view()
    {
        $this->redirect('/dashboard/tokens/tokens/');
    }

}
