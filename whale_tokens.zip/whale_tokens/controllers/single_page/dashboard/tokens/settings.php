<?php 
/**
 * @author 		shahroq <shahroq \at\ yahoo.com>
 * @copyright  	Copyright (c) 2014 shahroq.
 * http://concrete5.killerwhalesoft.com/addons/
 */
namespace Concrete\Package\WhaleTokens\Controller\SinglePage\Dashboard\Tokens;
use \Concrete\Core\Page\Controller\DashboardPageController;
use \Concrete\Core\Legacy\DatabaseItemList;
use Loader;
use Package;
use URL;

defined('C5_EXECUTE') or die(_("Access Denied."));

class Settings extends DashboardPageController
{

    public $conf = array();

    public function on_start()
    {
        $this->db = Loader::db();
        $this->error = Loader::helper('validation/error');
    }

	public function view()
    {
        $this->loadResources();

		$this->getConfigs();
		$this->set('conf', $this->conf);
	}

    public function update()
    {
        if ($this->isPost()) {
            $this->_validate();
            if (!$this->error->has()) {
                $this->_save();
                $this->redirect('/dashboard/tokens/settings/', 'update_done');
            }
        }
    }

    private function _validate()
    {
        $data = $_POST;

        //$this->error->add('error1');
        if (!(strlen($data['WHALE_TOKENS_WRAPPERS'])==2 || strlen($data['WHALE_TOKENS_WRAPPERS'])==0))
            $this->error->add(t('Tokens Wrappers should be empty or 2 characters.'));

        if ($this->error->has()) {
            return FALSE;
        }else{
            return TRUE;
        }
    }

    private function _save()
    {
        $data = $_POST;

        $pkg  = Package::getByHandle('whale_tokens');

        $pkg->getConfig()->save('tokens.WHALE_TOKENS_ENABLE', $data['WHALE_TOKENS_ENABLE']);
        $pkg->getConfig()->save('tokens.WHALE_TOKENS_WRAPPERS', $data['WHALE_TOKENS_WRAPPERS']);
        $pkg->getConfig()->save('tokens.WHALE_TOKENS_CASE_SENSITIVE', $data['WHALE_TOKENS_CASE_SENSITIVE'] );

    }

    public function update_done() {
        $this->set('message', t('Settings has been successfully saved. You should clear the cache, if it is enabled.'));
        $this->view();
    }

    //load resource (js, css)
    private function loadResources()
    {
        $hh = Loader::helper('html');
        $this->addHeaderItem($hh->css('token.dashboard.css','whale_tokens'));
        $this->addFooterItem($hh->javascript('funcs.tokens.dashboard.js','whale_tokens'));
    }

    private function getConfigs()
    {
        $pkg  = Package::getByHandle('whale_tokens');

        $this->conf = array('WHALE_TOKENS_ENABLE' => $pkg->getConfig()->get('tokens.WHALE_TOKENS_ENABLE'),
                            'WHALE_TOKENS_WRAPPERS' => $pkg->getConfig()->get('tokens.WHALE_TOKENS_WRAPPERS'),
                            'WHALE_TOKENS_CASE_SENSITIVE' => $pkg->getConfig()->get('tokens.WHALE_TOKENS_CASE_SENSITIVE')
                           );

        //divide token wrappers, if exist, and prepare them an an array for further use:
        $wrappers_ar = array("","");
        if(strlen($this->conf['WHALE_TOKENS_WRAPPERS'])==2) $wrappers_ar = str_split ( $this->conf['WHALE_TOKENS_WRAPPERS'] , 1 );
        $this->conf['WHALE_TOKENS_WRAPPERS_AR'] = $wrappers_ar;
    }

}