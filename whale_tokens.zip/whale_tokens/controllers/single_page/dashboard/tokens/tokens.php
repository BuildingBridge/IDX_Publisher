<?php 
/**
 * @author 		shahroq <shahroq \at\ yahoo.com>
 * @copyright  	Copyright (c) 2014 shahroq.
 * http://concrete5.killerwhalesoft.com/addons/
 */

namespace Concrete\Package\WhaleTokens\Controller\SinglePage\Dashboard\Tokens;
use \Concrete\Core\Page\Controller\DashboardPageController;
use \Concrete\Core\Legacy\DatabaseItemList;
use Loader;
use Package;
use stdClass;
use URL;

defined('C5_EXECUTE') or die("Access Denied.");

class NodesList extends DatabaseItemList
{
    public function setQuery($query)
    {
        $this->query = $query . ' ';
    }
    public function getQuery()
    {
        return $this->query;
    }
}

class Tokens extends DashboardPageController
{

    protected $package;

	public $tokenKey = '';
    public $tokenValue = '';
    public $itemsPerPage = 20;

    public $conf = array();

	public function on_start()
	{
        $this->db = Loader::db();
        //$this->db->debug = true;
        $this->error = Loader::helper('validation/error');
	}

	public function view()
	{
		$this->loadResources();

		$query = "SELECT * FROM WhaleTokens";
		$l = new NodesList();
		$l->setQuery($query);

		//set filters if user serach something:
		//keywords
		if ($_REQUEST['fKeywords'] != false && strlen($_REQUEST['fKeywords'])>0) {
			$val = trim($_REQUEST['fKeywords']);
			$q = sprintf( "(tokenID='%s' OR tokenKey LIKE '%%%s%%' OR tokenValue LIKE '%%%s%%')", $val, $val, $val);
			$l->filter(false, $q);
		}

		$l->sortByMultiple("tokenKey ASC, tokenID DESC");
		$l->setItemsPerPage($this->itemsPerPage);
		$list = $l->getPage();

		$this->set('list', $list);
		$this->set('l', $l);

        //get token wrappers:
		$this->getConfigs();
		$this->set('conf', $this->conf);
	}

	//load resource (js, css)
	private function loadResources()
	{
		$uh=Loader::helper('concrete/urls');
		$hh = Loader::helper('html');

        $this->addHeaderItem($hh->css('token.dashboard.css','whale_tokens'));
        $this->addFooterItem($hh->javascript('funcs.tokens.dashboard.js','whale_tokens'));
	}

	public function add()
	{
		$this->loadResources();

		//set default values
		$record = array(
						"tokenKey" => "",
                        "tokenValue" => "",
                        "active" => 1

						);
		$this->set('record', $record);

		if ($this->isPost()) {
			$this->_validate();
			if (!$this->error->has()) {
				$this->_save();
				$this->redirect('/dashboard/tokens/tokens/', 'record_added');
			}
		}
	}

	public function update()
	{
		$this->edit($this->post('tokenID'));

		if ($this->isPost()) {
			$this->_validate();
			if (!$this->error->has()) {
				$this->_save($this->post('tokenID'));
				$this->redirect('/dashboard/tokens/tokens/', 'record_updated');
			}
		}
	}

	public function edit($id)
	{
		$this->loadResources();

		//get record:
		$rslt = $this->db->Execute("SELECT * FROM `WhaleTokens` WHERE `tokenID`=? LIMIT 1;", array($id));//var_dump($rslt);die;
		if($rslt->numRows()<1) $this->redirect('/dashboard/tokens/tokens/');
		$record = $rslt->fetchRow();

		$this->set('record', $record);
	}

	private function _validate()
	{
		$hvs = Loader::helper('validation/strings');

		$data = $_POST;

		//$this->error->add('error1');
		if (!$hvs->min($data['tokenKey'],1) || !$hvs->max($data['tokenKey'],255)) $this->error->add(t('Token Key should have 1-255 character length.'));

		if(isset($data['tokenID'])){ //on update
			//check if token already exist:
			$sql = sprintf("SELECT `tokenID` FROM `WhaleTokens` WHERE `tokenID`<>%d AND `tokenKey`='%s'", $data['tokenID'], $data['tokenKey']);
			$rslt = $this->db->Execute($sql);
			if($rslt->numRows()>0) $this->error->add(t('Token with this key already exist.'));
		}

		if ($this->error->has()) {
			return FALSE;
		}else{
			return TRUE;
		}
	}

	private function _save($id=0)
	{
		$data = $_POST;

		if($id==0){
			$data_insert = array(
								$data['tokenKey'], $data['tokenValue'], (int)$data['active']
							);
			$this->db->Execute("INSERT INTO WhaleTokens (tokenKey, tokenValue, active) VALUES (?, ?, ?)",
					            $data_insert
					           );
		}else{
			$data_update = array(
					           $data['tokenKey'], $data['tokenValue'], (int)$data['active'], $id
					           );
			//print_r($data_update);die;
			$this->db->Execute("UPDATE WhaleTokens SET tokenKey=?, tokenValue=?, active=? WHERE tokenID=? LIMIT 1",
					            $data_update
					           );
		}
		$this->set('message', t('Your data has been successfully saved.'));

	}

	public function record_added()
	{
		$this->set('message', t('Record added.'));
		$this->view();
	}

	public function record_updated()
	{
		$this->set('message', t('Record updated. You should clear the cache, if it is enabled.'));
		$this->view();
	}

	public function mass_update()
	{
        $action = "";
        if(isset($_REQUEST['ccm-mass-update']) && $_REQUEST['ccm-mass-update']=="Delete"){ $action = "delete";}

		$selected_items = '0';
		if ($_REQUEST['cb_items']!=false && is_array($_REQUEST['cb_items'])) {

            $affected_rows = 0;
			foreach($_REQUEST['cb_items'] as $value){
			    $id_to_delete = (int)$value;
                $affected_rows += $this->delete_record($id_to_delete);
            }

            //output msg
            switch ($action) {
                case 'delete':
                    $this->set('message', $msg = t("%s Records Deleted.", $affected_rows));
                    break;
            }

		};

		$this->view();
	}

	private function delete_record($id)
	{
        $query = sprintf("DELETE FROM `WhaleTokens` WHERE tokenID = '%d'", $id);

        $r = $this->db->prepare($query);
        $rslt = $this->db->execute($r);
        if($rslt) return 1;
        return 0;
	}

    private function getConfigs()
    {
        $pkg  = Package::getByHandle('whale_tokens');

        $this->conf = array('WHALE_TOKENS_ENABLE' => $pkg->getConfig()->get('tokens.WHALE_TOKENS_ENABLE'),
        					'WHALE_TOKENS_WRAPPERS' => $pkg->getConfig()->get('tokens.WHALE_TOKENS_WRAPPERS'),
        					'WHALE_TOKENS_CASE_SENSITIVE' => $pkg->getConfig()->get('tokens.WHALE_TOKENS_CASE_SENSITIVE')
                           );

		//divide token wrappers, if exist, and prepare them an an array for further use:
        $wrappers_ar = array("","");
        if(strlen($this->conf['WHALE_TOKENS_WRAPPERS'])==2) $wrappers_ar = str_split ( $this->conf['WHALE_TOKENS_WRAPPERS'] , 1 );
		$this->conf['WHALE_TOKENS_WRAPPERS_AR'] = $wrappers_ar;
	}

}